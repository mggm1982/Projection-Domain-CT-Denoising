﻿# Projection-Domain CT Denoising

## Project overview

This project investigates deep-learning-based denoising of fan-beam CT
sinograms corrupted by Poisson noise. A DnCNN model is trained to predict
the noise residual. The denoised sinograms are evaluated in the projection
domain and after filtered back projection (FBP).

## Dataset

The dataset contains 300 synthetic phantoms.

- Training: 210 phantoms
- Validation: 45 phantoms
- Testing: 45 phantoms
- Sinogram dimensions: 720 x 512
- Dose levels: 1e04, 1e05 and 1e06
- Noise realisations: 3 per dose level

The dataset is stored separately from the code archive.

## Software requirements

- Python 3.12
- PyTorch 2.6.0 with CUDA 12.4
- ASTRA Toolbox 2.5.0
- NumPy, SciPy, scikit-image, Matplotlib, Pandas and BM3D

The supplied environment was tested with an NVIDIA GeForce RTX 4050
Laptop GPU.

## Folder structure

CT_Denoising_Submission/
|
|-- Training Data/
|   |-- Training/
|   |-- Validation/
|
|-- Testing Data/
|
|-- Code/
|   |-- Scripts/
|   |-- Models/
|   |   |-- dncnn_best.pth
|   |   |-- dncnn_test.pth
|   |-- requirements.txt
|   |-- README.md
|   |-- .venv/  (local environment; do not include in ZIP)
|
|-- dataset_manifest.json
|-- splits.json

## Environment setup (Windows PowerShell)

Open PowerShell in the Code directory.

Create a virtual environment:

    py -3.12 -m venv .venv

Install the dependencies:

    .\.venv\Scripts\python.exe -m pip install --upgrade pip
    .\.venv\Scripts\python.exe -m pip install -r requirements.txt

Verify PyTorch and CUDA:

    .\.venv\Scripts\python.exe -c "import torch; print(torch.__version__); print(torch.cuda.is_available()); print(torch.cuda.get_device_name(0) if torch.cuda.is_available() else 'CPU')"

## Training

The training script is:

    Scripts/train_full.py

Run it from the Code directory:

    .\.venv\Scripts\python.exe .\Scripts\train_full.py

The script reads the dataset manifest from the submission root and saves
the best validation checkpoint to:

    Models/dncnn_best.pth

Note: Running training may overwrite the existing best checkpoint.
Keep a backup before starting a new training run.

## Model and dataset verification

Test the dataset loader:

    .\.venv\Scripts\python.exe .\Scripts\dncnn_dataset.py

The trained checkpoint is stored in the Models directory.

## Evaluation and visualisation

Additional scripts for evaluation, baseline comparisons and visualisation
are provided in the Scripts directory. These include:

- evaluate_sinogram.py
- evaluate_fbp.py
- compare_all_methods.py
- visualize_all_methods.py
- visualize_fbp.py

Check any input/output path settings in an evaluation script before
running it on a different computer.

## Reproducibility notes

The training configuration uses:

- Patch size: 64 x 64
- Training patches per epoch: 10,000
- Validation patches per epoch: 2,000
- Batch size: 32
- Epochs: 60
- Optimizer: Adam
- Learning rate: 0.001
- Loss: Mean squared error on the predicted noise residual
- Random seed: 20261004

The supplied model checkpoints are included so that inference and
evaluation can be performed without retraining.

## Notes

The Training Data and Testing Data folders are distributed separately
from the code ZIP because of their size.

The .venv folder is a local Python environment and should not be
included in the submission ZIP.
