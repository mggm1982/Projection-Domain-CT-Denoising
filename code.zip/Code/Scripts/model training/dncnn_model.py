import torch
import torch.nn as nn


class DnCNN(nn.Module):
    def __init__(self, channels=1, features=64, depth=15):
        super().__init__()

        layers = [
            nn.Conv2d(channels, features, kernel_size=3, padding=1),
            nn.ReLU(inplace=True)
        ]

        for _ in range(depth):
            layers += [
                nn.Conv2d(features, features, kernel_size=3, padding=1),
                nn.BatchNorm2d(features),
                nn.ReLU(inplace=True)
            ]

        layers += [
            nn.Conv2d(features, channels, kernel_size=3, padding=1)
        ]

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        # Predict the noise/residual
        return self.network(x)


if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    model = DnCNN().to(device)

    x = torch.randn(2, 1, 64, 64, device=device)
    residual = model(x)
    denoised = x - residual

    print("Device:", device)
    print("Input:", x.shape)
    print("Predicted residual:", residual.shape)
    print("Denoised output:", denoised.shape)
    print("Parameters:", sum(p.numel() for p in model.parameters()))
