
import json
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import Dataset


class SinogramPatchDataset(Dataset):
    def __init__(
        self,
        manifest_path,
        split,
        patch_size=64,
        patches_per_epoch=20000,
        seed=20261004,
    ):
        self.patch_size = patch_size
        self.patches_per_epoch = patches_per_epoch
        self.rng = np.random.default_rng(seed)

        manifest_path = Path(manifest_path).resolve()
        self.data_root = manifest_path.parent

        with open(manifest_path, "r") as f:
            rows = json.load(f)

        self.rows = [r for r in rows if r["split"] == split]

        if not self.rows:
            raise ValueError(f"No samples found for split: {split}")

    def __len__(self):
        return self.patches_per_epoch

    def __getitem__(self, idx):
        row = self.rows[self.rng.integers(len(self.rows))]

        noisy_path = self.data_root / row["noisy_path"]
        clean_path = self.data_root / row["clean_path"]

        noisy = np.load(noisy_path).astype(np.float32)
        clean = np.load(clean_path).astype(np.float32)

        h, w = noisy.shape
        ps = self.patch_size

        y = self.rng.integers(0, h - ps + 1)
        x = self.rng.integers(0, w - ps + 1)

        noisy_patch = noisy[y:y+ps, x:x+ps]
        clean_patch = clean[y:y+ps, x:x+ps]

        residual_patch = noisy_patch - clean_patch

        noisy_patch = torch.from_numpy(noisy_patch).unsqueeze(0)
        clean_patch = torch.from_numpy(clean_patch).unsqueeze(0)
        residual_patch = torch.from_numpy(residual_patch).unsqueeze(0)

        return {
            "noisy": noisy_patch,
            "clean": clean_patch,
            "residual": residual_patch,
            "dose": row["dose"],
            "phantom": row["phantom"],
        }


if __name__ == "__main__":
    code_dir = Path(__file__).resolve().parent
    submission_root = code_dir.parent.parent

    dataset = SinogramPatchDataset(
        submission_root / "dataset_manifest.json",
        split="train",
        patch_size=64,
        patches_per_epoch=10,
    )

    sample = dataset[0]

    print("Dataset samples:", len(dataset))
    print("Noisy patch:", sample["noisy"].shape)
    print("Clean patch:", sample["clean"].shape)
    print("Residual patch:", sample["residual"].shape)
    print("Dose:", sample["dose"])
    print("Phantom:", sample["phantom"])
