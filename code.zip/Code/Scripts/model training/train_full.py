
from pathlib import Path
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from dncnn_dataset import SinogramPatchDataset
from dncnn_model import DnCNN

# Project paths
CODE_DIR = Path(__file__).resolve().parent
SUBMISSION_ROOT = CODE_DIR.parent.parent
MANIFEST = SUBMISSION_ROOT / "dataset_manifest.json"
MODEL_OUT = CODE_DIR.parent / "Models" / "dncnn_best.pth"

# Training configuration
PATCH_SIZE = 64
TRAIN_PATCHES = 10000
VAL_PATCHES = 2000
BATCH_SIZE = 32
EPOCHS = 60
LEARNING_RATE = 1e-3

# Device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print("Device:", device)

if device.type == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))

# Datasets
train_dataset = SinogramPatchDataset(
    str(MANIFEST),
    split="train",
    patch_size=PATCH_SIZE,
    patches_per_epoch=TRAIN_PATCHES
)

val_dataset = SinogramPatchDataset(
    str(MANIFEST),
    split="val",
    patch_size=PATCH_SIZE,
    patches_per_epoch=VAL_PATCHES
)

train_loader = DataLoader(
    train_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=(device.type == "cuda")
)

val_loader = DataLoader(
    val_dataset,
    batch_size=BATCH_SIZE,
    shuffle=False,
    num_workers=0,
    pin_memory=(device.type == "cuda")
)

print("Training patches:", len(train_dataset))
print("Validation patches:", len(val_dataset))

# Model
model = DnCNN().to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=LEARNING_RATE)

# Training
best_val_loss = float("inf")
MODEL_OUT.parent.mkdir(parents=True, exist_ok=True)

for epoch in range(EPOCHS):
    model.train()
    train_loss = 0.0

    for batch in train_loader:
        noisy = batch["noisy"].to(device, non_blocking=True)
        residual = batch["residual"].to(device, non_blocking=True)

        optimizer.zero_grad()
        predicted_residual = model(noisy)
        loss = criterion(predicted_residual, residual)
        loss.backward()
        optimizer.step()

        train_loss += loss.item() * noisy.size(0)

    train_loss /= len(train_dataset)

    model.eval()
    val_loss = 0.0

    with torch.no_grad():
        for batch in val_loader:
            noisy = batch["noisy"].to(device, non_blocking=True)
            residual = batch["residual"].to(device, non_blocking=True)

            predicted_residual = model(noisy)
            loss = criterion(predicted_residual, residual)
            val_loss += loss.item() * noisy.size(0)

    val_loss /= len(val_dataset)

    print(
        f"Epoch {epoch + 1:02d}/{EPOCHS} | "
        f"Train Loss: {train_loss:.6f} | "
        f"Val Loss: {val_loss:.6f}"
    )

    if val_loss < best_val_loss:
        best_val_loss = val_loss

        torch.save(
            {
                "epoch": epoch + 1,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "train_loss": train_loss,
                "val_loss": val_loss,
            },
            MODEL_OUT
        )

        print("  -> Best model saved.")

print("\nTraining complete.")
print("Best validation loss:", best_val_loss)
print("Best model:", MODEL_OUT)
