import json
import numpy as np
import torch
from pathlib import Path
from dncnn_model import DnCNN


# --------------------------------------------------
# Paths
# --------------------------------------------------
ROOT = Path(r"C:\CT_Project\ct_project20_300phantoms")
MANIFEST = ROOT / "dataset_manifest.json"
MODEL_PATH = Path(r"C:\CT_Project\dncnn_best.pth")

# --------------------------------------------------
# Settings
# --------------------------------------------------
PATCH_SIZE = 64
STRIDE = 32
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


# --------------------------------------------------
# PSNR
# --------------------------------------------------
def psnr(reference, estimate):
    mse = np.mean((reference - estimate) ** 2)

    if mse == 0:
        return float("inf")

    data_range = reference.max() - reference.min()

    return 10 * np.log10((data_range ** 2) / mse)


# --------------------------------------------------
# Full-sinogram DnCNN inference
# --------------------------------------------------
def denoise_sinogram(model, noisy):

    h, w = noisy.shape

    output = np.zeros_like(noisy, dtype=np.float32)
    weight = np.zeros_like(noisy, dtype=np.float32)

    model.eval()

    with torch.no_grad():

        for y in range(0, h - PATCH_SIZE + 1, STRIDE):

            for x in range(0, w - PATCH_SIZE + 1, STRIDE):

                patch = noisy[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ]

                tensor = torch.from_numpy(
                    patch.astype(np.float32)
                ).unsqueeze(0).unsqueeze(0).to(DEVICE)

                predicted_residual = model(tensor)

                denoised = tensor - predicted_residual

                denoised = denoised.squeeze().cpu().numpy()

                output[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += denoised

                weight[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += 1.0

    # Handle borders
    for y in range(0, h, STRIDE):
        y0 = min(y, h - PATCH_SIZE)

        for x in range(0, w, STRIDE):
            x0 = min(x, w - PATCH_SIZE)

            patch = noisy[
                y0:y0 + PATCH_SIZE,
                x0:x0 + PATCH_SIZE
            ]

            tensor = torch.from_numpy(
                patch.astype(np.float32)
            ).unsqueeze(0).unsqueeze(0).to(DEVICE)

            with torch.no_grad():
                predicted_residual = model(tensor)
                denoised = tensor - predicted_residual

            denoised = denoised.squeeze().cpu().numpy()

            output[
                y0:y0 + PATCH_SIZE,
                x0:x0 + PATCH_SIZE
            ] += denoised

            weight[
                y0:y0 + PATCH_SIZE,
                x0:x0 + PATCH_SIZE
            ] += 1.0

    return output / np.maximum(weight, 1e-8)


# --------------------------------------------------
# Load manifest
# --------------------------------------------------
with open(MANIFEST, "r") as f:
    manifest = json.load(f)

rows = manifest

test_rows = [
    row for row in rows
    if row["split"] == "test"
]

print("Device:", DEVICE)

if DEVICE.type == "cuda":
    print("GPU:", torch.cuda.get_device_name(0))

print("Test samples:", len(test_rows))


# --------------------------------------------------
# Load model
# --------------------------------------------------
model = DnCNN().to(DEVICE)

checkpoint = torch.load(
    MODEL_PATH,
    map_location=DEVICE
)

model.load_state_dict(
    checkpoint["model_state_dict"]
)

model.eval()

print("Model loaded.")
print("Best epoch:", checkpoint["epoch"])
print("Best validation loss:", checkpoint["val_loss"])


# --------------------------------------------------
# Evaluate
# --------------------------------------------------
results = []

for i, row in enumerate(test_rows):

    noisy = np.load(
        ROOT.parent / row["noisy_path"]
    ).astype(np.float32)

    clean = np.load(
        ROOT.parent / row["clean_path"]
    ).astype(np.float32)

    denoised = denoise_sinogram(
        model,
        noisy
    )

    noisy_psnr = psnr(clean, noisy)
    denoised_psnr = psnr(clean, denoised)

    noisy_rmse = np.sqrt(
        np.mean((clean - noisy) ** 2)
    )

    denoised_rmse = np.sqrt(
        np.mean((clean - denoised) ** 2)
    )

    results.append({
        "phantom": row["phantom"],
        "dose": row["dose"],
        "realization": row["realization"],
        "noisy_psnr": float(noisy_psnr),
        "denoised_psnr": float(denoised_psnr),
        "noisy_rmse": float(noisy_rmse),
        "denoised_rmse": float(denoised_rmse),
    })

    print(
        f"{i + 1:03d}/{len(test_rows)} | "
        f"{row['phantom']} | "
        f"Dose {row['dose']} | "
        f"Noisy PSNR: {noisy_psnr:.2f} dB | "
        f"DnCNN PSNR: {denoised_psnr:.2f} dB"
    )


# --------------------------------------------------
# Save results
# --------------------------------------------------
with open(
    ROOT / "sinogram_test_results.json",
    "w"
) as f:
    json.dump(results, f, indent=2)


# --------------------------------------------------
# Summary by dose
# --------------------------------------------------
print("\n==============================")
print("SINOGRAM TEST RESULTS")
print("==============================")

for dose in sorted(set(r["dose"] for r in results)):

    subset = [
        r for r in results
        if r["dose"] == dose
    ]

    noisy_mean = np.mean(
        [r["noisy_psnr"] for r in subset]
    )

    denoised_mean = np.mean(
        [r["denoised_psnr"] for r in subset]
    )

    noisy_rmse = np.mean(
        [r["noisy_rmse"] for r in subset]
    )

    denoised_rmse = np.mean(
        [r["denoised_rmse"] for r in subset]
    )

    print(f"\nDose: {dose}")
    print(f"Noisy PSNR:    {noisy_mean:.3f} dB")
    print(f"DnCNN PSNR:    {denoised_mean:.3f} dB")
    print(f"PSNR gain:     {denoised_mean - noisy_mean:.3f} dB")
    print(f"Noisy RMSE:    {noisy_rmse:.6f}")
    print(f"DnCNN RMSE:    {denoised_rmse:.6f}")

print("\nResults saved to:")
print(ROOT / "sinogram_test_results.json")
