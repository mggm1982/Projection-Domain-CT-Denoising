
import os
import numpy as np
import torch
import astra
import pandas as pd

from skimage.metrics import (
    peak_signal_noise_ratio,
    structural_similarity,
)
from dncnn_model import DnCNN

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------
ROOT = r"C:\CT_Project"
DATASET = os.path.join(ROOT, "ct_project20_300phantoms")
CHECKPOINT = os.path.join(ROOT, "dncnn_best.pth")

PHANTOM = "phantom_009"
REALIZATION = 1
DOSES = ["1e04", "1e05", "1e06"]

PATCH_SIZE = 64
STRIDE = 32

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --------------------------------------------------
# LOAD MODEL
# --------------------------------------------------
model = DnCNN().to(device)
checkpoint = torch.load(CHECKPOINT, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

print("Model loaded on:", device)

# --------------------------------------------------
# DnCNN SINOGRAM DENOISING
# --------------------------------------------------
def denoise_sinogram(sino):
    h, w = sino.shape
    output = np.zeros_like(sino, dtype=np.float32)
    weight = np.zeros_like(sino, dtype=np.float32)

    ys = list(range(0, h - PATCH_SIZE + 1, STRIDE))
    xs = list(range(0, w - PATCH_SIZE + 1, STRIDE))

    if not ys or ys[-1] != h - PATCH_SIZE:
        ys.append(h - PATCH_SIZE)
    if not xs or xs[-1] != w - PATCH_SIZE:
        xs.append(w - PATCH_SIZE)

    with torch.no_grad():
        for y in ys:
            for x in xs:
                patch = sino[y:y + PATCH_SIZE, x:x + PATCH_SIZE].copy()
                inp = torch.from_numpy(patch).float()[None, None].to(device)

                residual = model(inp)
                denoised = (inp - residual).squeeze().cpu().numpy()

                output[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += denoised
                weight[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += 1.0

    return output / np.maximum(weight, 1e-8)

# --------------------------------------------------
# ASTRA FBP
# --------------------------------------------------
angles = np.linspace(0, 2 * np.pi, 720, endpoint=False)

proj_geom = astra.create_proj_geom(
    "fanflat", 1.0, 512, angles, 600, 400
)
vol_geom = astra.create_vol_geom(512, 512)


def reconstruct_fbp(sino):
    sino_id = astra.data2d.create("-sino", proj_geom, sino)
    rec_id = astra.data2d.create("-vol", vol_geom)

    cfg = astra.astra_dict("FBP_CUDA")
    cfg["ProjectionDataId"] = sino_id
    cfg["ReconstructionDataId"] = rec_id
    cfg["option"] = {"FilterType": "Ram-Lak"}

    alg_id = astra.algorithm.create(cfg)

    try:
        astra.algorithm.run(alg_id)
        reconstruction = astra.data2d.get(rec_id).astype(np.float32)
    finally:
        astra.algorithm.delete(alg_id)
        astra.data2d.delete(sino_id)
        astra.data2d.delete(rec_id)

    return reconstruction

# --------------------------------------------------
# EVALUATION
# --------------------------------------------------
records = []

for dose in DOSES:
    print(f"\nEvaluating dose {dose}...")

    folder = os.path.join(DATASET, PHANTOM)

    clean_sino = np.load(
        os.path.join(folder, "clean_sinogram.npy")
    ).astype(np.float32)

    noisy_sino = np.load(
        os.path.join(folder, f"dose_{dose}", f"realization_{REALIZATION}.npy")
    ).astype(np.float32)

    dncnn_sino = denoise_sinogram(noisy_sino)

    # Sinogram-domain metrics
    sino_range = float(clean_sino.max() - clean_sino.min())

    noisy_sino_psnr = peak_signal_noise_ratio(
        clean_sino, noisy_sino, data_range=sino_range
    )
    dncnn_sino_psnr = peak_signal_noise_ratio(
        clean_sino, dncnn_sino, data_range=sino_range
    )

    noisy_sino_ssim = structural_similarity(
        clean_sino, noisy_sino, data_range=sino_range
    )
    dncnn_sino_ssim = structural_similarity(
        clean_sino, dncnn_sino, data_range=sino_range
    )

    # FBP image-domain metrics
    clean_fbp = reconstruct_fbp(clean_sino)
    noisy_fbp = reconstruct_fbp(noisy_sino)
    dncnn_fbp = reconstruct_fbp(dncnn_sino)

    image_range = float(clean_fbp.max() - clean_fbp.min())

    noisy_fbp_psnr = peak_signal_noise_ratio(
        clean_fbp, noisy_fbp, data_range=image_range
    )
    dncnn_fbp_psnr = peak_signal_noise_ratio(
        clean_fbp, dncnn_fbp, data_range=image_range
    )

    noisy_fbp_ssim = structural_similarity(
        clean_fbp, noisy_fbp, data_range=image_range
    )
    dncnn_fbp_ssim = structural_similarity(
        clean_fbp, dncnn_fbp, data_range=image_range
    )

    records.append({
        "dose": dose,
        "noisy_sinogram_psnr": noisy_sino_psnr,
        "dncnn_sinogram_psnr": dncnn_sino_psnr,
        "sinogram_psnr_gain": dncnn_sino_psnr - noisy_sino_psnr,
        "noisy_sinogram_ssim": noisy_sino_ssim,
        "dncnn_sinogram_ssim": dncnn_sino_ssim,
        "sinogram_ssim_gain": dncnn_sino_ssim - noisy_sino_ssim,
        "noisy_fbp_psnr": noisy_fbp_psnr,
        "dncnn_fbp_psnr": dncnn_fbp_psnr,
        "fbp_psnr_gain": dncnn_fbp_psnr - noisy_fbp_psnr,
        "noisy_fbp_ssim": noisy_fbp_ssim,
        "dncnn_fbp_ssim": dncnn_fbp_ssim,
        "fbp_ssim_gain": dncnn_fbp_ssim - noisy_fbp_ssim,
    })

    print(
        f"Sinogram PSNR: {noisy_sino_psnr:.3f} -> "
        f"{dncnn_sino_psnr:.3f} dB "
        f"(gain {dncnn_sino_psnr - noisy_sino_psnr:+.3f} dB)"
    )
    print(
        f"Sinogram SSIM: {noisy_sino_ssim:.4f} -> "
        f"{dncnn_sino_ssim:.4f}"
    )
    print(
        f"FBP PSNR:      {noisy_fbp_psnr:.3f} -> "
        f"{dncnn_fbp_psnr:.3f} dB "
        f"(gain {dncnn_fbp_psnr - noisy_fbp_psnr:+.3f} dB)"
    )
    print(
        f"FBP SSIM:      {noisy_fbp_ssim:.4f} -> "
        f"{dncnn_fbp_ssim:.4f}"
    )

# --------------------------------------------------
# SAVE RESULTS
# --------------------------------------------------
results = pd.DataFrame(records)
output_path = os.path.join(ROOT, "dncnn_domain_diagnostic.csv")
results.to_csv(output_path, index=False)

print("\nDOMAIN COMPARISON SUMMARY")
print(results.round(4).to_string(index=False))
print(f"\nSaved results to: {output_path}")
