import json
import numpy as np
import torch
import astra
from pathlib import Path
from dncnn_model import DnCNN


# --------------------------------------------------
# Paths
# --------------------------------------------------
ROOT = Path(r"C:\CT_Project\ct_project20_300phantoms")
MANIFEST = ROOT / "dataset_manifest.json"
MODEL_PATH = Path(r"C:\CT_Project\dncnn_best.pth")

DEVICE = torch.device(
    "cuda" if torch.cuda.is_available() else "cpu"
)


# --------------------------------------------------
# Geometry
# --------------------------------------------------
N_DETECTORS = 512
N_VIEWS = 720

DET_SPACING = 1.0
SOD = 600.0
ODD = 400.0

ANGLES = np.linspace(
    0,
    2 * np.pi,
    N_VIEWS,
    endpoint=False
)


# --------------------------------------------------
# Load manifest
# --------------------------------------------------
with open(MANIFEST, "r") as f:
    rows = json.load(f)

test_rows = [
    row for row in rows
    if row["split"] == "test"
]

row = test_rows[0]

print("Testing:")
print("Phantom:", row["phantom"])
print("Dose:", row["dose"])
print("Realization:", row["realization"])


# --------------------------------------------------
# Load sinograms
# --------------------------------------------------
noisy = np.load(
    ROOT.parent / row["noisy_path"]
).astype(np.float32)

clean = np.load(
    ROOT.parent / row["clean_path"]
).astype(np.float32)

print("Sinogram shape:", noisy.shape)


# --------------------------------------------------
# Load DnCNN
# --------------------------------------------------
model = DnCNN().to(DEVICE)

checkpoint = torch.load(
    MODEL_PATH,
    map_location=DEVICE
)

model.load_state_dict(
    checkpoint["model_state_dict"]
)

model.eval()


# --------------------------------------------------
# DnCNN full-sinogram inference
# --------------------------------------------------
PATCH_SIZE = 64
STRIDE = 32


def denoise_sinogram(model, noisy):

    h, w = noisy.shape

    output = np.zeros_like(
        noisy,
        dtype=np.float32
    )

    weight = np.zeros_like(
        noisy,
        dtype=np.float32
    )

    with torch.no_grad():

        ys = list(range(0, h - PATCH_SIZE + 1, STRIDE))
        xs = list(range(0, w - PATCH_SIZE + 1, STRIDE))

        if ys[-1] != h - PATCH_SIZE:
            ys.append(h - PATCH_SIZE)

        if xs[-1] != w - PATCH_SIZE:
            xs.append(w - PATCH_SIZE)

        for y in ys:
            for x in xs:

                patch = noisy[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ]

                tensor = torch.from_numpy(
                    patch
                ).unsqueeze(0).unsqueeze(0).to(DEVICE)

                residual = model(tensor)

                denoised = tensor - residual

                denoised = (
                    denoised
                    .squeeze()
                    .cpu()
                    .numpy()
                )

                output[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += denoised

                weight[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += 1.0

    return output / np.maximum(
        weight,
        1e-8
    )


print("Running DnCNN...")

denoised = denoise_sinogram(
    model,
    noisy
)

print("DnCNN complete.")


# --------------------------------------------------
# ASTRA fan-beam FBP
# --------------------------------------------------
proj_geom = astra.create_proj_geom(
    "fanflat",
    DET_SPACING,
    N_DETECTORS,
    ANGLES,
    SOD,
    ODD
)

vol_geom = astra.create_vol_geom(
    512,
    512
)


def fbp_reconstruct(sinogram):

    sino_id = astra.data2d.create(
        "-sino",
        proj_geom,
        sinogram
    )

    rec_id = astra.data2d.create(
        "-vol",
        vol_geom
    )

    cfg = astra.astra_dict(
        "FBP_CUDA"
    )

    cfg["ProjectionDataId"] = sino_id
    cfg["ReconstructionDataId"] = rec_id

    alg_id = astra.algorithm.create(cfg)

    astra.algorithm.run(alg_id)

    reconstruction = astra.data2d.get(
        rec_id
    )

    astra.algorithm.delete(alg_id)
    astra.data2d.delete(sino_id)
    astra.data2d.delete(rec_id)

    return reconstruction.astype(
        np.float32
    )


print("Running clean FBP...")
clean_fbp = fbp_reconstruct(clean)

print("Running noisy FBP...")
noisy_fbp = fbp_reconstruct(noisy)

print("Running DnCNN FBP...")
denoised_fbp = fbp_reconstruct(denoised)


# --------------------------------------------------
# Save
# --------------------------------------------------
np.save(
    ROOT / "test_clean_fbp.npy",
    clean_fbp
)

np.save(
    ROOT / "test_noisy_fbp.npy",
    noisy_fbp
)

np.save(
    ROOT / "test_dncnn_fbp.npy",
    denoised_fbp
)


# --------------------------------------------------
# Basic statistics
# --------------------------------------------------
print("\nFBP COMPLETE")
print("----------------------------")

print(
    "Clean FBP:",
    clean_fbp.min(),
    clean_fbp.max(),
    clean_fbp.mean()
)

print(
    "Noisy FBP:",
    noisy_fbp.min(),
    noisy_fbp.max(),
    noisy_fbp.mean()
)

print(
    "DnCNN FBP:",
    denoised_fbp.min(),
    denoised_fbp.max(),
    denoised_fbp.mean()
)

print("\nSaved test reconstructions.")

from skimage.metrics import peak_signal_noise_ratio, structural_similarity

# ----------------------------
# Image-domain metrics
# ----------------------------

clean = clean_fbp
noisy = noisy_fbp
dncnn = denoised_fbp

# Use clean FBP as reference
data_range = clean.max() - clean.min()

noisy_psnr = peak_signal_noise_ratio(
    clean, noisy, data_range=data_range
)

dncnn_psnr = peak_signal_noise_ratio(
    clean, dncnn, data_range=data_range
)

noisy_ssim = structural_similarity(
    clean, noisy, data_range=data_range
)

dncnn_ssim = structural_similarity(
    clean, dncnn, data_range=data_range
)

print("\nIMAGE-DOMAIN METRICS")
print("----------------------------")
print(f"Noisy  FBP: PSNR = {noisy_psnr:.4f} dB, SSIM = {noisy_ssim:.4f}")
print(f"DnCNN  FBP: PSNR = {dncnn_psnr:.4f} dB, SSIM = {dncnn_ssim:.4f}")
print(f"PSNR gain:  {dncnn_psnr - noisy_psnr:+.4f} dB")
print(f"SSIM gain:  {dncnn_ssim - noisy_ssim:+.4f}")