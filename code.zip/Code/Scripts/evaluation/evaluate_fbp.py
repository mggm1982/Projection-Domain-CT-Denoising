import os
import json
import csv
import numpy as np
import torch
import astra

from skimage.metrics import peak_signal_noise_ratio, structural_similarity
from dncnn_model import DnCNN


# ============================================================
# Paths
# ============================================================

ROOT = r"C:\CT_Project"
DATASET_DIR = os.path.join(ROOT, "ct_project20_300phantoms")
MANIFEST_PATH = os.path.join(DATASET_DIR, "dataset_manifest.json")
CHECKPOINT = os.path.join(ROOT, "dncnn_best.pth")

OUTPUT_CSV = os.path.join(ROOT, "fbp_test_results.csv")
OUTPUT_SUMMARY = os.path.join(ROOT, "fbp_test_summary.csv")


# ============================================================
# Device
# ============================================================

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

print("Device:", DEVICE)

if torch.cuda.is_available():
    print("GPU:", torch.cuda.get_device_name(0))


# ============================================================
# Load manifest
# ============================================================

with open(MANIFEST_PATH, "r") as f:
    manifest = json.load(f)

# dataset_manifest.json is a list
rows = manifest

# Keep only test samples
rows = [r for r in rows if r["split"] == "test"]

print("Test samples:", len(rows))


# ============================================================
# Load DnCNN
# ============================================================

model = DnCNN().to(DEVICE)

checkpoint = torch.load(
    CHECKPOINT,
    map_location=DEVICE
)

model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

print("Model loaded.")
print("Best epoch:", checkpoint["epoch"])
print("Best validation loss:", checkpoint["val_loss"])


# ============================================================
# DnCNN full-sinogram inference
# ============================================================

PATCH_SIZE = 64
STRIDE = 32


def denoise_sinogram(noisy):

    h, w = noisy.shape

    output = np.zeros_like(noisy, dtype=np.float32)
    weight = np.zeros_like(noisy, dtype=np.float32)

    # Include final patch so no border is left uncovered
    ys = list(range(0, h - PATCH_SIZE + 1, STRIDE))
    xs = list(range(0, w - PATCH_SIZE + 1, STRIDE))

    if ys[-1] != h - PATCH_SIZE:
        ys.append(h - PATCH_SIZE)

    if xs[-1] != w - PATCH_SIZE:
        xs.append(w - PATCH_SIZE)

    with torch.no_grad():

        for y in ys:
            for x in xs:

                patch = noisy[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ]

                tensor = torch.from_numpy(
                    patch
                ).unsqueeze(0).unsqueeze(0).to(DEVICE)

                residual = model(tensor)

                denoised = tensor - residual

                denoised = denoised.squeeze().cpu().numpy()

                output[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += denoised

                weight[
                    y:y + PATCH_SIZE,
                    x:x + PATCH_SIZE
                ] += 1.0

    output /= np.maximum(weight, 1e-8)

    return output.astype(np.float32)


# ============================================================
# ASTRA fan-beam geometry
# ============================================================

NUM_DETECTORS = 512
NUM_VIEWS = 720

DETECTOR_SPACING = 1.0
SOD = 600.0
ODD = 400.0

angles = np.linspace(
    0,
    2 * np.pi,
    NUM_VIEWS,
    endpoint=False
)

proj_geom = astra.create_proj_geom(
    "fanflat",
    DETECTOR_SPACING,
    NUM_DETECTORS,
    angles,
    SOD,
    ODD
)

vol_geom = astra.create_vol_geom(
    512,
    512
)


# ============================================================
# FBP reconstruction
# ============================================================

def fbp_reconstruct(sinogram):

    sino_id = astra.data2d.create(
        "-sino",
        proj_geom,
        sinogram
    )

    rec_id = astra.data2d.create(
        "-vol",
        vol_geom
    )

    cfg = astra.astra_dict("FBP_CUDA")

    cfg["ProjectionDataId"] = sino_id
    cfg["ReconstructionDataId"] = rec_id

    algorithm_id = astra.algorithm.create(cfg)

    astra.algorithm.run(algorithm_id)

    reconstruction = astra.data2d.get(rec_id)

    astra.algorithm.delete(algorithm_id)
    astra.data2d.delete(sino_id)
    astra.data2d.delete(rec_id)

    return reconstruction.astype(np.float32)


# ============================================================
# Evaluate
# ============================================================

results = []

for i, row in enumerate(rows, start=1):

    noisy_path = os.path.join(ROOT, row["noisy_path"])
    clean_path = os.path.join(ROOT, row["clean_path"])

    noisy_sino = np.load(noisy_path).astype(np.float32)
    clean_sino = np.load(clean_path).astype(np.float32)

    # --------------------------------------------------------
    # DnCNN
    # --------------------------------------------------------

    denoised_sino = denoise_sinogram(noisy_sino)

    # --------------------------------------------------------
    # FBP
    # --------------------------------------------------------

    clean_fbp = fbp_reconstruct(clean_sino)
    noisy_fbp = fbp_reconstruct(noisy_sino)
    denoised_fbp = fbp_reconstruct(denoised_sino)

    # --------------------------------------------------------
    # Metrics
    # --------------------------------------------------------

    data_range = float(
        clean_fbp.max() - clean_fbp.min()
    )

    noisy_psnr = peak_signal_noise_ratio(
        clean_fbp,
        noisy_fbp,
        data_range=data_range
    )

    dncnn_psnr = peak_signal_noise_ratio(
        clean_fbp,
        denoised_fbp,
        data_range=data_range
    )

    noisy_ssim = structural_similarity(
        clean_fbp,
        noisy_fbp,
        data_range=data_range
    )

    dncnn_ssim = structural_similarity(
        clean_fbp,
        denoised_fbp,
        data_range=data_range
    )

    psnr_gain = dncnn_psnr - noisy_psnr
    ssim_gain = dncnn_ssim - noisy_ssim

    result = {
        "phantom": row["phantom"],
        "dose": row["dose"],
        "realization": row["realization"],
        "noisy_psnr": float(noisy_psnr),
        "dncnn_psnr": float(dncnn_psnr),
        "psnr_gain": float(psnr_gain),
        "noisy_ssim": float(noisy_ssim),
        "dncnn_ssim": float(dncnn_ssim),
        "ssim_gain": float(ssim_gain),
    }

    results.append(result)

    print(
        f"{i:03d}/{len(rows)} | "
        f"{row['phantom']} | "
        f"Dose {row['dose']} | "
        f"Noisy PSNR: {noisy_psnr:.2f} dB | "
        f"DnCNN PSNR: {dncnn_psnr:.2f} dB | "
        f"Noisy SSIM: {noisy_ssim:.4f} | "
        f"DnCNN SSIM: {dncnn_ssim:.4f}"
    )


# ============================================================
# Save individual results
# ============================================================

fieldnames = [
    "phantom",
    "dose",
    "realization",
    "noisy_psnr",
    "dncnn_psnr",
    "psnr_gain",
    "noisy_ssim",
    "dncnn_ssim",
    "ssim_gain",
]

with open(OUTPUT_CSV, "w", newline="") as f:

    writer = csv.DictWriter(
        f,
        fieldnames=fieldnames
    )

    writer.writeheader()
    writer.writerows(results)


# ============================================================
# Dose-wise summary
# ============================================================

summary = []

for dose in ["1e04", "1e05", "1e06"]:

    dose_results = [
        r for r in results
        if r["dose"] == dose
    ]

    def mean(key):
        return float(
            np.mean([r[key] for r in dose_results])
        )

    def std(key):
        return float(
            np.std([r[key] for r in dose_results])
        )

    summary.append({
        "dose": dose,
        "n": len(dose_results),

        "noisy_psnr_mean": mean("noisy_psnr"),
        "noisy_psnr_std": std("noisy_psnr"),

        "dncnn_psnr_mean": mean("dncnn_psnr"),
        "dncnn_psnr_std": std("dncnn_psnr"),

        "psnr_gain_mean": mean("psnr_gain"),
        "psnr_gain_std": std("psnr_gain"),

        "noisy_ssim_mean": mean("noisy_ssim"),
        "noisy_ssim_std": std("noisy_ssim"),

        "dncnn_ssim_mean": mean("dncnn_ssim"),
        "dncnn_ssim_std": std("dncnn_ssim"),

        "ssim_gain_mean": mean("ssim_gain"),
        "ssim_gain_std": std("ssim_gain"),
    })


summary_fields = list(summary[0].keys())

with open(OUTPUT_SUMMARY, "w", newline="") as f:

    writer = csv.DictWriter(
        f,
        fieldnames=summary_fields
    )

    writer.writeheader()
    writer.writerows(summary)


# ============================================================
# Print final summary
# ============================================================

print("\n========================================")
print("IMAGE-DOMAIN TEST SUMMARY")
print("========================================")

for s in summary:

    print(f"\nDose: {s['dose']}")
    print(f"Samples: {s['n']}")

    print(
        f"Noisy  PSNR: "
        f"{s['noisy_psnr_mean']:.4f} ± "
        f"{s['noisy_psnr_std']:.4f} dB"
    )

    print(
        f"DnCNN  PSNR: "
        f"{s['dncnn_psnr_mean']:.4f} ± "
        f"{s['dncnn_psnr_std']:.4f} dB"
    )

    print(
        f"PSNR gain: "
        f"{s['psnr_gain_mean']:+.4f} ± "
        f"{s['psnr_gain_std']:.4f} dB"
    )

    print(
        f"Noisy  SSIM: "
        f"{s['noisy_ssim_mean']:.4f} ± "
        f"{s['noisy_ssim_std']:.4f}"
    )

    print(
        f"DnCNN  SSIM: "
        f"{s['dncnn_ssim_mean']:.4f} ± "
        f"{s['dncnn_ssim_std']:.4f}"
    )

    print(
        f"SSIM gain: "
        f"{s['ssim_gain_mean']:+.4f} ± "
        f"{s['ssim_gain_std']:.4f}"
    )


print("\nSaved:")
print(OUTPUT_CSV)
print(OUTPUT_SUMMARY)