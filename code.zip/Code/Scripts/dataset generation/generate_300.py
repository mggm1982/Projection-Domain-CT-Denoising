import json
from pathlib import Path
import numpy as np

from test import (
    PHANTOM_SIZE,
    DOSES,
    N_REALIZATIONS,
    ELECTRONIC_SIGMA,
    MASTER_SEED,
    make_prototype_phantom,
    make_astra_geometry,
    forward_project,
    simulate_noisy_sinogram,
    reconstruct_fbp,
)

N_PHANTOMS = 300

OUT = Path("ct_project20_300phantoms")
OUT.mkdir(exist_ok=True)

rng_master = np.random.default_rng(MASTER_SEED)

print("Creating ASTRA fan-beam geometry...")
vol_geom, proj_geom = make_astra_geometry(PHANTOM_SIZE)

for phantom_id in range(N_PHANTOMS):

    print(f"\n===== PHANTOM {phantom_id + 1}/{N_PHANTOMS} =====")

    phantom_rng = np.random.default_rng(
        int(rng_master.integers(0, 2**32 - 1))
    )

    phantom = make_prototype_phantom(
        PHANTOM_SIZE,
        rng=phantom_rng
    )

    phantom_dir = OUT / f"phantom_{phantom_id:03d}"
    phantom_dir.mkdir(exist_ok=True)

    np.save(phantom_dir / "phantom.npy", phantom)

    print("Generating clean sinogram...")
    clean_sino = forward_project(
        phantom,
        vol_geom,
        proj_geom
    )

    np.save(phantom_dir / "clean_sinogram.npy", clean_sino)

    for dose in DOSES:

        dose_dir = phantom_dir / f"dose_{dose:.0e}".replace("+", "")
        dose_dir.mkdir(exist_ok=True)

        print(f"  Dose I0 = {dose:.0e}")

        for realization in range(1, N_REALIZATIONS + 1):

            seed = int(rng_master.integers(0, 2**32 - 1))
            rng = np.random.default_rng(seed)

            noisy = simulate_noisy_sinogram(
                clean_sino,
                dose,
                rng,
                ELECTRONIC_SIGMA
            )

            np.save(
                dose_dir / f"realization_{realization}.npy",
                noisy
            )

            reconstruction = reconstruct_fbp(
                noisy,
                proj_geom,
                vol_geom
            )

            np.save(
                dose_dir / f"realization_{realization}_fbp.npy",
                reconstruction
            )

            print(f"    realization {realization} saved")

print("\n===================================")
print("20-PHANTOM DATASET GENERATION DONE")
print(f"Output: {OUT}")
print("===================================")
