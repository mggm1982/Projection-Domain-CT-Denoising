
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------
ROOT = Path(r"C:\CT_Project")
OUTPUT = ROOT / "final_comparison"

OUTPUT.mkdir(parents=True, exist_ok=True)

FILES = {
    "dncnn": ROOT / "fbp_test_summary.csv",
    "gaussian": ROOT / "gaussian_baseline_summary.csv",
    "bilateral": ROOT / "bilateral_baseline_summary.csv",
    "bm3d": ROOT / "bm3d_baseline_summary.csv",
}

DOSES = [10000.0, 100000.0, 1000000.0]

# --------------------------------------------------
# LOAD SUMMARIES
# --------------------------------------------------
for name, path in FILES.items():
    if not path.exists():
        raise FileNotFoundError(f"Missing summary file: {path}")

dncnn = pd.read_csv(FILES["dncnn"])
gaussian = pd.read_csv(FILES["gaussian"])
bilateral = pd.read_csv(FILES["bilateral"])
bm3d = pd.read_csv(FILES["bm3d"])

# Convert dose to numeric so all files align correctly.
for df in [dncnn, gaussian, bilateral, bm3d]:
    df["dose"] = pd.to_numeric(df["dose"], errors="raise")

# Check expected doses.
for name, df in [
    ("DnCNN", dncnn),
    ("Gaussian", gaussian),
    ("Bilateral", bilateral),
    ("BM3D", bm3d),
]:
    if set(df["dose"]) != set(DOSES):
        raise ValueError(
            f"{name} has unexpected dose levels: {sorted(df['dose'].unique())}"
        )

# --------------------------------------------------
# BUILD COMPARISON TABLE
# --------------------------------------------------
tables = []

for dose in DOSES:
    d = dncnn.loc[dncnn["dose"] == dose].iloc[0]
    g = gaussian.loc[gaussian["dose"] == dose].iloc[0]
    b = bilateral.loc[bilateral["dose"] == dose].iloc[0]
    m = bm3d.loc[bm3d["dose"] == dose].iloc[0]

    # Ensure the reported noisy baseline is consistent.
    noisy_psnr_values = [
        d["noisy_psnr_mean"],
        g["noisy_psnr_mean"],
        b["noisy_psnr_mean"],
        m["noisy_psnr_mean"],
    ]
    noisy_ssim_values = [
        d["noisy_ssim_mean"],
        g["noisy_ssim_mean"],
        b["noisy_ssim_mean"],
        m["noisy_ssim_mean"],
    ]

    if not np.allclose(noisy_psnr_values, noisy_psnr_values[0], atol=1e-4):
        raise ValueError(f"Noisy PSNR mismatch at dose {dose}")

    if not np.allclose(noisy_ssim_values, noisy_ssim_values[0], atol=1e-5):
        raise ValueError(f"Noisy SSIM mismatch at dose {dose}")

    tables.append({
        "dose": dose,
        "samples": int(d["n"]),
        "noisy_psnr": d["noisy_psnr_mean"],
        "gaussian_psnr": g["gaussian_psnr_mean"],
        "bilateral_psnr": b["bilateral_psnr_mean"],
        "bm3d_psnr": m["bm3d_psnr_mean"],
        "dncnn_psnr": d["dncnn_psnr_mean"],
        "noisy_ssim": d["noisy_ssim_mean"],
        "gaussian_ssim": g["gaussian_ssim_mean"],
        "bilateral_ssim": b["bilateral_ssim_mean"],
        "bm3d_ssim": m["bm3d_ssim_mean"],
        "dncnn_ssim": d["dncnn_ssim_mean"],
    })

comparison = pd.DataFrame(tables).sort_values("dose")

# Calculate gains over the same noisy FBP reference.
for method in ["gaussian", "bilateral", "bm3d", "dncnn"]:
    comparison[f"{method}_psnr_gain"] = (
        comparison[f"{method}_psnr"] - comparison["noisy_psnr"]
    )
    comparison[f"{method}_ssim_gain"] = (
        comparison[f"{method}_ssim"] - comparison["noisy_ssim"]
    )

comparison["dose_label"] = comparison["dose"].map({
    10000.0: "1e4",
    100000.0: "1e5",
    1000000.0: "1e6",
})

# Save the complete table.
comparison.to_csv(
    OUTPUT / "all_methods_comparison.csv",
    index=False,
    float_format="%.6f",
)

# Also save a compact table of PSNR and SSIM means.
compact_columns = [
    "dose_label",
    "samples",
    "noisy_psnr",
    "gaussian_psnr",
    "bilateral_psnr",
    "bm3d_psnr",
    "dncnn_psnr",
    "noisy_ssim",
    "gaussian_ssim",
    "bilateral_ssim",
    "bm3d_ssim",
    "dncnn_ssim",
]

comparison[compact_columns].to_csv(
    OUTPUT / "report_metrics_table.csv",
    index=False,
    float_format="%.4f",
)

print("\nFINAL METHOD COMPARISON")
print(comparison[compact_columns].to_string(index=False))

# --------------------------------------------------
# PLOTTING
# --------------------------------------------------
methods = {
    "Noisy FBP": "noisy",
    "Gaussian": "gaussian",
    "Bilateral": "bilateral",
    "BM3D": "bm3d",
    "DnCNN": "dncnn",
}

x = np.arange(len(comparison))
dose_labels = comparison["dose_label"].tolist()

def make_plot(metric, ylabel, title, filename):
    plt.figure(figsize=(9, 5.5))

    for label, prefix in methods.items():
        plt.plot(
            x,
            comparison[f"{prefix}_{metric}"],
            marker="o",
            linewidth=2,
            markersize=6,
            label=label,
        )

    plt.xticks(x, dose_labels)
    plt.xlabel("Photon dose level")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT / filename, dpi=300, bbox_inches="tight")
    plt.close()

def make_gain_plot(metric, ylabel, title, filename):
    plt.figure(figsize=(9, 5.5))

    gain_methods = [
        ("Gaussian", "gaussian"),
        ("Bilateral", "bilateral"),
        ("BM3D", "bm3d"),
        ("DnCNN", "dncnn"),
    ]

    width = 0.18
    offsets = np.linspace(
        -1.5 * width, 1.5 * width, len(gain_methods)
    )

    for offset, (label, prefix) in zip(offsets, gain_methods):
        plt.bar(
            x + offset,
            comparison[f"{prefix}_{metric}_gain"],
            width=width,
            label=label,
        )

    plt.xticks(x, dose_labels)
    plt.xlabel("Photon dose level")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.axhline(0, linewidth=0.8)
    plt.grid(axis="y", alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(OUTPUT / filename, dpi=300, bbox_inches="tight")
    plt.close()

make_plot(
    "psnr",
    "PSNR (dB)",
    "Image-domain PSNR across denoising methods",
    "psnr_comparison.png",
)

make_plot(
    "ssim",
    "SSIM",
    "Image-domain SSIM across denoising methods",
    "ssim_comparison.png",
)

make_gain_plot(
    "psnr",
    "PSNR improvement (dB)",
    "PSNR improvement over noisy FBP",
    "psnr_gain_comparison.png",
)

make_gain_plot(
    "ssim",
    "SSIM improvement",
    "SSIM improvement over noisy FBP",
    "ssim_gain_comparison.png",
)

print("\nSaved comparison files to:")
print(OUTPUT)
print("\nGenerated:")
print("- all_methods_comparison.csv")
print("- report_metrics_table.csv")
print("- psnr_comparison.png")
print("- ssim_comparison.png")
print("- psnr_gain_comparison.png")
print("- ssim_gain_comparison.png")
