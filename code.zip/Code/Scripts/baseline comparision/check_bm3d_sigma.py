
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter

ROOT = Path(r"C:\CT_Project")
DATASET = ROOT / "ct_project20_300phantoms"
PHANTOM = "phantom_009"

for dose in ["1e04", "1e05", "1e06"]:
    folder = DATASET / PHANTOM

    clean = np.load(folder / "clean_sinogram.npy").astype(np.float32)
    noisy = np.load(
        folder / f"dose_{dose}" / "realization_1.npy"
    ).astype(np.float32)

    sino_min = float(clean.min())
    sino_range = float(clean.max() - sino_min)

    noisy_norm = np.clip(
        (noisy - sino_min) / sino_range, 0.0, 1.0
    )

    sigma = float(
        np.std(
            noisy_norm - gaussian_filter(noisy_norm, sigma=1.0)
        )
    )

    print(
        f"Dose {dose}: "
        f"estimated sigma = {sigma:.6f}, "
        f"clean range = {sino_range:.6f}"
    )
