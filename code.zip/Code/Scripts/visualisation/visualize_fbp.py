import os
import numpy as np
import matplotlib.pyplot as plt

ROOT = r"C:\CT_Project"
DATASET_DIR = os.path.join(ROOT, "ct_project20_300phantoms")

# Representative test sample
phantom = "phantom_009"
dose = "1e04"

clean_path = os.path.join(ROOT, "ct_project20_300phantoms", "test_clean_fbp.npy")
noisy_path = os.path.join(ROOT, "ct_project20_300phantoms", "test_noisy_fbp.npy")
dncnn_path = os.path.join(ROOT, "ct_project20_300phantoms", "test_dncnn_fbp.npy")

clean = np.load(clean_path)
noisy = np.load(noisy_path)
dncnn = np.load(dncnn_path)

error_noisy = np.abs(noisy - clean)
error_dncnn = np.abs(dncnn - clean)

fig, axes = plt.subplots(2, 3, figsize=(15, 9))

images = [
    clean,
    noisy,
    dncnn,
    error_noisy,
    error_dncnn,
    np.abs(dncnn - noisy)
]

titles = [
    "Clean FBP",
    "Noisy FBP",
    "DnCNN + FBP",
    "|Noisy − Clean|",
    "|DnCNN − Clean|",
    "|DnCNN − Noisy|"
]

for ax, img, title in zip(axes.ravel(), images, titles):
    if "Clean" in title and "Error" not in title:
        vmin = clean.min()
        vmax = clean.max()
    elif "DnCNN + FBP" in title:
        vmin = clean.min()
        vmax = clean.max()
    elif "Noisy FBP" in title:
        vmin = clean.min()
        vmax = clean.max()
    else:
        vmin = 0
        vmax = np.percentile(img, 99)

    ax.imshow(img, cmap="gray", vmin=vmin, vmax=vmax)
    ax.set_title(title)
    ax.axis("off")

fig.suptitle(
    f"Projection-Domain DnCNN CT Denoising\n"
    f"{phantom} | Dose = {dose} | Realization = 1",
    fontsize=16
)

plt.tight_layout()

output = os.path.join(ROOT, "fbp_visual_comparison.png")
plt.savefig(output, dpi=300, bbox_inches="tight")
plt.show()

print(f"Saved: {output}")