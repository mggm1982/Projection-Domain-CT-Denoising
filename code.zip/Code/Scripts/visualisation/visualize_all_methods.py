
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import astra
import bm3d

from scipy.ndimage import gaussian_filter
from skimage.restoration import denoise_bilateral
from dncnn_model import DnCNN

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------
ROOT = r"C:\CT_Project"
DATASET_DIR = os.path.join(ROOT, "ct_project20_300phantoms")
CHECKPOINT = os.path.join(ROOT, "dncnn_best.pth")

PHANTOM = "phantom_009"
REALIZATION = 1
DOSES = ["1e04", "1e05", "1e06"]

PATCH_SIZE = 64
STRIDE = 32

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --------------------------------------------------
# LOAD DnCNN
# --------------------------------------------------
model = DnCNN().to(device)
checkpoint = torch.load(CHECKPOINT, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

print("DnCNN loaded on:", device)

# --------------------------------------------------
# DnCNN SINOGRAM DENOISING
# --------------------------------------------------
def denoise_sinogram(sino):
    h, w = sino.shape
    output = np.zeros_like(sino, dtype=np.float32)
    weight = np.zeros_like(sino, dtype=np.float32)

    ys = list(range(0, h - PATCH_SIZE + 1, STRIDE))
    xs = list(range(0, w - PATCH_SIZE + 1, STRIDE))

    if ys[-1] != h - PATCH_SIZE:
        ys.append(h - PATCH_SIZE)
    if xs[-1] != w - PATCH_SIZE:
        xs.append(w - PATCH_SIZE)

    with torch.no_grad():
        for y in ys:
            for x in xs:
                patch = sino[y:y + PATCH_SIZE, x:x + PATCH_SIZE]
                inp = torch.from_numpy(patch.copy()).float()
                inp = inp.unsqueeze(0).unsqueeze(0).to(device)

                residual = model(inp)
                denoised = (inp - residual).squeeze().cpu().numpy()

                output[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += denoised
                weight[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += 1.0

    return output / np.maximum(weight, 1e-8)

# --------------------------------------------------
# FILTERS
# --------------------------------------------------
def gaussian_denoise(sino):
    return gaussian_filter(sino, sigma=1.0).astype(np.float32)


def bilateral_denoise(sino):
    sino_min = float(sino.min())
    sino_range = float(sino.max() - sino_min)

    if sino_range <= 0:
        return sino.copy()

    normalized = (sino - sino_min) / sino_range

    filtered = denoise_bilateral(
        normalized,
        sigma_color=0.1,
        sigma_spatial=3,
        channel_axis=None,
    )

    return (filtered * sino_range + sino_min).astype(np.float32)


def bm3d_denoise(sino, clean_sino):
    # Oracle noise estimate for this representative visual comparison.
    sino_min = float(clean_sino.min())
    sino_range = float(clean_sino.max() - sino_min)

    if sino_range <= 0:
        return sino.copy()

    normalized = np.clip(
        (sino - sino_min) / sino_range, 0.0, 1.0
    )

    sigma = float(np.std(sino - clean_sino) / sino_range)
    sigma = max(sigma, 1e-6)

    filtered = bm3d.bm3d(normalized, sigma_psd=sigma)

    return (np.asarray(filtered) * sino_range + sino_min).astype(np.float32)

# --------------------------------------------------
# ASTRA FBP
# --------------------------------------------------
angles = np.linspace(0, 2 * np.pi, 720, endpoint=False)

proj_geom = astra.create_proj_geom(
    "fanflat", 1.0, 512, angles, 600, 400
)
vol_geom = astra.create_vol_geom(512, 512)


def fbp_reconstruct(sino):
    sino_id = astra.data2d.create("-sino", proj_geom, sino)
    rec_id = astra.data2d.create("-vol", vol_geom)

    cfg = astra.astra_dict("FBP_CUDA")
    cfg["ProjectionDataId"] = sino_id
    cfg["ReconstructionDataId"] = rec_id
    cfg["option"] = {"FilterType": "Ram-Lak"}

    alg_id = astra.algorithm.create(cfg)

    try:
        astra.algorithm.run(alg_id)
        reconstruction = astra.data2d.get(rec_id).astype(np.float32)
    finally:
        astra.algorithm.delete(alg_id)
        astra.data2d.delete(sino_id)
        astra.data2d.delete(rec_id)

    return reconstruction

# --------------------------------------------------
# PROCESS ALL DOSES
# --------------------------------------------------
results = {}

for dose in DOSES:
    print(f"\nProcessing dose {dose}...")

    phantom_dir = os.path.join(DATASET_DIR, PHANTOM)

    clean_path = os.path.join(phantom_dir, "clean_sinogram.npy")
    noisy_path = os.path.join(
        phantom_dir, f"dose_{dose}", f"realization_{REALIZATION}.npy"
    )

    clean_sino = np.load(clean_path).astype(np.float32)
    noisy_sino = np.load(noisy_path).astype(np.float32)

    print("  Denoising with Gaussian...")
    gaussian_sino = gaussian_denoise(noisy_sino)

    print("  Denoising with bilateral...")
    bilateral_sino = bilateral_denoise(noisy_sino)

    print("  Denoising with BM3D...")
    bm3d_sino = bm3d_denoise(noisy_sino, clean_sino)

    print("  Denoising with DnCNN...")
    dncnn_sino = denoise_sinogram(noisy_sino)

    print("  Reconstructing with FBP...")
    clean_fbp = fbp_reconstruct(clean_sino)

    reconstructions = {
        "Clean FBP": clean_fbp,
        "Noisy FBP": fbp_reconstruct(noisy_sino),
        "Gaussian": fbp_reconstruct(gaussian_sino),
        "Bilateral": fbp_reconstruct(bilateral_sino),
        "BM3D": fbp_reconstruct(bm3d_sino),
        "DnCNN": fbp_reconstruct(dncnn_sino),
    }

    results[dose] = reconstructions

print("\nAll doses processed.")

# --------------------------------------------------
# PLOT COMPARISON
# --------------------------------------------------
columns = ["Clean FBP", "Noisy FBP", "Gaussian",
           "Bilateral", "BM3D", "DnCNN"]

fig, axes = plt.subplots(3, 6, figsize=(21, 11))

for r, dose in enumerate(DOSES):
    clean = results[dose]["Clean FBP"]
    vmin, vmax = clean.min(), clean.max()

    for c, name in enumerate(columns):
        axes[r, c].imshow(
            results[dose][name],
            cmap="gray",
            vmin=vmin,
            vmax=vmax,
        )
        axes[r, c].set_title(name)
        axes[r, c].axis("off")

    axes[r, 0].set_ylabel(f"Dose {dose}", fontsize=12)

fig.suptitle(
    f"CT Reconstruction Comparison: {PHANTOM}, "
    f"Realization {REALIZATION}",
    fontsize=16,
)
plt.tight_layout()

output = os.path.join(ROOT, "all_methods_visual_comparison.png")
plt.savefig(output, dpi=300, bbox_inches="tight")
plt.show()

print(f"Saved comparison image: {output}")
