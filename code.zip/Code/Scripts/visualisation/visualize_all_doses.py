
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import astra

from dncnn_model import DnCNN

# --------------------------------------------------
# CONFIGURATION
# --------------------------------------------------
ROOT = r"C:\CT_Project"
DATASET_DIR = os.path.join(ROOT, "ct_project20_300phantoms")
CHECKPOINT = os.path.join(ROOT, "dncnn_best.pth")

PHANTOM = "phantom_009"
REALIZATION = 1
DOSES = ["1e04", "1e05", "1e06"]

PATCH_SIZE = 64
STRIDE = 32

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# --------------------------------------------------
# LOAD DnCNN
# --------------------------------------------------
model = DnCNN().to(device)
checkpoint = torch.load(CHECKPOINT, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.eval()

print("Model loaded on:", device)


# --------------------------------------------------
# DnCNN SINOGRAM DENOISING
# --------------------------------------------------
def denoise_sinogram(sino):
    h, w = sino.shape

    output = np.zeros_like(sino, dtype=np.float32)
    weight = np.zeros_like(sino, dtype=np.float32)

    ys = list(range(0, h - PATCH_SIZE + 1, STRIDE))
    xs = list(range(0, w - PATCH_SIZE + 1, STRIDE))

    if not ys or ys[-1] != h - PATCH_SIZE:
        ys.append(h - PATCH_SIZE)

    if not xs or xs[-1] != w - PATCH_SIZE:
        xs.append(w - PATCH_SIZE)

    with torch.no_grad():
        for y in ys:
            for x in xs:
                patch = sino[y:y + PATCH_SIZE, x:x + PATCH_SIZE]

                inp = torch.from_numpy(patch.copy()).float()
                inp = inp.unsqueeze(0).unsqueeze(0).to(device)

                residual = model(inp)
                denoised = (inp - residual).squeeze().cpu().numpy()

                output[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += denoised
                weight[y:y + PATCH_SIZE, x:x + PATCH_SIZE] += 1.0

    return output / np.maximum(weight, 1e-8)


# --------------------------------------------------
# ASTRA FBP
# --------------------------------------------------
angles = np.linspace(0, 2 * np.pi, 720, endpoint=False)

proj_geom = astra.create_proj_geom(
    "fanflat", 1.0, 512, angles, 600, 400
)
vol_geom = astra.create_vol_geom(512, 512)


def fbp_reconstruct(sino):
    sino_id = astra.data2d.create("-sino", proj_geom, sino)
    rec_id = astra.data2d.create("-vol", vol_geom)

    cfg = astra.astra_dict("FBP_CUDA")
    cfg["ProjectionDataId"] = sino_id
    cfg["ReconstructionDataId"] = rec_id
    cfg["option"] = {"FilterType": "Ram-Lak"}

    alg_id = astra.algorithm.create(cfg)

    try:
        astra.algorithm.run(alg_id)
        reconstruction = astra.data2d.get(rec_id).astype(np.float32)
    finally:
        astra.algorithm.delete(alg_id)
        astra.data2d.delete(sino_id)
        astra.data2d.delete(rec_id)

    return reconstruction


# --------------------------------------------------
# PROCESS ALL THREE DOSES
# --------------------------------------------------
results = {}

for dose in DOSES:
    print(f"Processing dose {dose}...")

    phantom_dir = os.path.join(DATASET_DIR, PHANTOM)

    clean_path = os.path.join(phantom_dir, "clean_sinogram.npy")
    noisy_path = os.path.join(
        phantom_dir,
        f"dose_{dose}",
        f"realization_{REALIZATION}.npy",
    )

    clean_sino = np.load(clean_path).astype(np.float32)
    noisy_sino = np.load(noisy_path).astype(np.float32)

    print("  DnCNN denoising...")
    dncnn_sino = denoise_sinogram(noisy_sino)

    print("  FBP reconstruction...")
    clean_fbp = fbp_reconstruct(clean_sino)
    noisy_fbp = fbp_reconstruct(noisy_sino)
    dncnn_fbp = fbp_reconstruct(dncnn_sino)

    results[dose] = {
        "clean_sino": clean_sino,
        "noisy_sino": noisy_sino,
        "dncnn_sino": dncnn_sino,
        "clean_fbp": clean_fbp,
        "noisy_fbp": noisy_fbp,
        "dncnn_fbp": dncnn_fbp,
    }

print("All three doses completed.")


# --------------------------------------------------
# FIGURE 1: SINOGRAM COMPARISON
# --------------------------------------------------
fig, axes = plt.subplots(3, 3, figsize=(16, 12))

for r, dose in enumerate(DOSES):
    clean = results[dose]["clean_sino"]
    noisy = results[dose]["noisy_sino"]
    dncnn = results[dose]["dncnn_sino"]

    vmin = float(clean.min())
    vmax = float(clean.max())

    images = [clean, noisy, dncnn]
    titles = ["Clean Sinogram", "Noisy Sinogram", "DnCNN Sinogram"]

    for c, (img, title) in enumerate(zip(images, titles)):
        axes[r, c].imshow(
            img,
            cmap="gray",
            aspect="auto",
            vmin=vmin,
            vmax=vmax,
        )
        axes[r, c].set_title(title)
        axes[r, c].set_xlabel("Detector index")
        axes[r, c].set_ylabel(f"Dose {dose}\nProjection angle")

fig.suptitle(
    f"Projection-Domain Comparison: {PHANTOM}, "
    f"Realization {REALIZATION}",
    fontsize=16,
)
plt.tight_layout()

sino_output = os.path.join(ROOT, "sinogram_all_doses_comparison.png")
plt.savefig(sino_output, dpi=300, bbox_inches="tight")
plt.show()
plt.close(fig)

print("Saved:", sino_output)


# --------------------------------------------------
# FIGURE 2: FBP RECONSTRUCTION COMPARISON
# --------------------------------------------------
fig, axes = plt.subplots(3, 4, figsize=(16, 12))

for r, dose in enumerate(DOSES):
    clean = results[dose]["clean_fbp"]
    noisy = results[dose]["noisy_fbp"]
    dncnn = results[dose]["dncnn_fbp"]

    error_noisy = np.abs(noisy - clean)
    error_dncnn = np.abs(dncnn - clean)

    vmin = float(clean.min())
    vmax = float(clean.max())

    error_limit = float(np.percentile(
        np.concatenate([error_noisy.ravel(), error_dncnn.ravel()]),
        99,
    ))
    error_limit = max(error_limit, 1e-8)

    images = [clean, noisy, dncnn, error_dncnn]
    titles = [
        "Clean FBP",
        "Noisy FBP",
        "DnCNN + FBP",
        "|DnCNN - Clean|",
    ]

    for c, (img, title) in enumerate(zip(images, titles)):
        if c < 3:
            axes[r, c].imshow(
                img, cmap="gray", vmin=vmin, vmax=vmax
            )
        else:
            axes[r, c].imshow(
                img, cmap="magma", vmin=0, vmax=error_limit
            )

        axes[r, c].set_title(title)
        axes[r, c].axis("off")

    axes[r, 0].set_ylabel(f"Dose {dose}", fontsize=12)

fig.suptitle(
    f"FBP Reconstruction Comparison: {PHANTOM}, "
    f"Realization {REALIZATION}",
    fontsize=16,
)
plt.tight_layout()

fbp_output = os.path.join(ROOT, "fbp_all_doses_comparison.png")
plt.savefig(fbp_output, dpi=300, bbox_inches="tight")
plt.show()
plt.close(fig)

print("Saved:", fbp_output)
print("\nVisualization complete.")
