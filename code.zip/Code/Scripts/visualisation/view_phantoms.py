import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path

folder = Path(r"C:\CT_Project\phantom_images_300")

files = sorted(folder.glob("phantom_*.npy"))[:9]

fig, axes = plt.subplots(3, 3, figsize=(9, 9))

for ax, file in zip(axes.flat, files):
    phantom = np.load(file)
    ax.imshow(phantom, cmap="gray")
    ax.set_title(file.stem)
    ax.axis("off")

plt.tight_layout()
plt.savefig("phantom_samples.png", dpi=300)
plt.show()